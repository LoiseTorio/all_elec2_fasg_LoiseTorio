import 'dart:ui';

const Color green = Color(0xffa28d2f);
const Color lightGrey = Color(0xff5f6367);
const Color shim = Color(0x7f000000);
