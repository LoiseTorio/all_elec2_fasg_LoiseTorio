class FooderlichPages {
  static String splashPath = '/splash';
  static String loginPath = '/login';
  static String onboardingPath = '/onboarding';
  static String home = '/';
  static String groceryItemDetails = '/item';
  static String profilePath = '/profile';
  static String raywenderlich = '/raywenderlich';
  static String accountPath = '/account';
}
