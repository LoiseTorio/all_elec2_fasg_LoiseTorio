import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';

class LoginScreen extends StatelessWidget {
  static MaterialPage page() {
    return MaterialPage(
        name: FooderlichPages.loginPath,
        key: ValueKey(FooderlichPages.loginPath),
        child: const LoginScreen());
  }

  final String? username;
  final String? password;

  const LoginScreen({
    Key? key,
    this.username,
    this.password,
  }) : super(key: key);

  final Color rwColor = const Color(0xff3065ec);
  final TextStyle focusedStyle = const TextStyle(color: Color(0xff16e000));
  final TextStyle unfocusedStyle = const TextStyle(color: Color(0xffb8ff00));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffff830c),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                height: 230,
                child: Image(
                  image: AssetImage('assets/fooderlich_assets/Pops.png'),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              buildTextfield(
                username ?? 'username',
                textStyle: TextStyle(color: Color(0xff000000)),
              ),
              const SizedBox(
                height: 10,
              ),
              buildTextfield(
                password ?? 'password',
                textStyle: TextStyle(color: Color(0xff000000)),
              ),
              const SizedBox(height: 10),
              buildButton(context)
            ],
          ),
        ),
      ),
    );
  }

  Widget buildButton(BuildContext context) {
    return SizedBox(
      height: 55,
      child: MaterialButton(
        color: rwColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        child: const Text(
          'Login',
          style: TextStyle(color: Colors.white),
        ),
        onPressed: () async {
          Provider.of<AppStateManager>(context, listen: false)
              .login('mockUsername', 'mockPassword');
        },
      ),
    );
  }

  Widget buildTextfield(String hintText, {required TextStyle textStyle}) {
    return TextField(
      cursorColor: rwColor,
      decoration: InputDecoration(
        border: const OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0xffa21313),
            width: 5.0,
          ),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xffa21313)),
        ),
        hintText: hintText,
        hintStyle: const TextStyle(height: 0.5),
      ),
    );
  }
}
